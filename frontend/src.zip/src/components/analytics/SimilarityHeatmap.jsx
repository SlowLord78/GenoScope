import { useEffect, useRef } from "react";
import Plotly from "plotly.js-dist-min";

import useGenomeStore from "../../store/useGenomeStore";

export default function SimilarityHeatmap() {
  const chartRef = useRef(null);
  const statistics = useGenomeStore((state) => state.statistics);

  useEffect(() => {
    const element = chartRef.current;

    if (!statistics?.similarity_matrix || !element) return;

    const matrix = statistics.similarity_matrix;

    Plotly.react(
      element,
      [
        {
          z: matrix.values,
          x: matrix.labels,
          y: matrix.labels,
          type: "heatmap",
          colorscale: "Viridis",
          hoverongaps: false,
        },
      ],
      {
        paper_bgcolor: "rgba(0,0,0,0)",
        plot_bgcolor: "rgba(0,0,0,0)",
        font: { color: "white" },
        height: 600,
        margin: { t: 30, r: 30, b: 120, l: 120 },
      },
      {
        responsive: true,
        displaylogo: false,
      }
    );

    return () => {
      if (element) {
        try {
          Plotly.purge(element);
        } catch {
          // Nettoyage ignoré si React a déjà démonté le DOM.
        }
      }
    };
  }, [statistics]);

  if (!statistics?.similarity_matrix) {
    return null;
  }

  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-xl">
      <h2 className="mb-6 text-2xl font-bold">
        Similarity Matrix
      </h2>

      <div ref={chartRef} className="min-h-[600px] w-full" />
    </div>
  );
}